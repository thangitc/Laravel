<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    protected $table='vt_video';
    public function singer()
    {
        return $this->belongsToMany(Singer::class, 'vt_video_singer', 'video_id', 'singer_id');
    }
    public function cats()
    {
        return $this->belongsToMany(Cats::class, 'vt_video_category', 'video_id', 'category_id');
    }
}
