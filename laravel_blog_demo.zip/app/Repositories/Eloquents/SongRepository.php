<?php

namespace App\Repositories\Eloquents;

use App\Repositories\Contracts\SongRepositoryInterface;

use Illuminate\Support\Facades\DB;
use App\Song;
use App\Singer;
//use DB;
use Cache;

class SongRepository implements SongRepositoryInterface
{
    public function all()
    {
        return Song::all();
    }

    public function find($id)
    {
        return Song::find($id);
    }
    public function getSongDetail($identify)
    {
        $minutes = 15;
        if(Cache::has('getSongDetail'.$identify))
        {
            $a = Cache::get('getSongDetail'.$identify);
        }
        else
        {
            $a = Song::where('identify','=',$identify)->first();
            Cache::put('getSongDetail'.$identify, $a, $minutes);
        }
        return $a;
    }
    public function getSongRelated()
    {
        $minutes = 15;
        if(Cache::has('getSongRelated'))
        {
            $a = Cache::get('getSongRelated');
        }
        else
        {
            $a = Song::where('name','LIKE', '%lactroi%')->get();
            Cache::put('getSongRelated', $a, $minutes);
        }
        return $a;

    }
    public function getSongHot()
    {
        $minutes = 15;
        if(Cache::has('getSongHot'))
        {
            $a = Cache::get('getSongHot');
        }
        else
        {
            $a = Song::where('listen_no_week','>',200)->orderBy('listen_no_week', 'DESC')->take(20)->get();
            Cache::put('getSongHot', $a, $minutes);
        }
        return $a;
    }
    public function getSingerBySong($song_id)
    {
        $minutes = 15;
        if(Cache::has('getSingerBySong'.$song_id))
        {
            $a = Cache::get('getSingerBySong'.$song_id);
        }
        else
        {
            $a = Song::find($song_id)->singer()->first();
            Cache::put('getSingerBySong'.$song_id, $a, $minutes);
        }

        return $a;
    }
    public function getCatBySong($song_id)
    {
        $minutes = 15;
        if(Cache::has('getCatBySong'.$song_id))
        {
            $a = Cache::get('getCatBySong'.$song_id);
        }
        else
        {
            $a = Song::find($song_id)->cats()->first();
            Cache::put('getCatBySong'.$song_id, $a, $minutes);
        }

        return $a;
    }
    public function getAuthorBySong($song_id)
    {
        $minutes = 15;
        if(Cache::has('getAuthorBySong'.$song_id))
        {
            $a = Cache::get('getAuthorBySong'.$song_id);
        }
        else
        {
            $a = Song::find($song_id)->author()->first();
            Cache::put('getAuthorBySong'.$song_id, $a, $minutes);
        }
        return $a;
    }
}