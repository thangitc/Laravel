<?php

namespace App\Repositories\Eloquents;

use App\Repositories\Contracts\VideoRepositoryInterface;
use App\Video;
//use Illuminate\Support\Facades\DB;
use DB;
use Cache;

class VideoRepository implements VideoRepositoryInterface
{
    public function all()
    {
        return Video::all();
    }

    public function find($id)
    {
        return Video::find($id);
    }
    public function getVideoDetail($identify)
    {
        $minutes = 15;
        if(Cache::has('getVideoDetail'.$identify))
        {
            $a = Cache::get('getVideoDetail'.$identify);
        }
        else
        {
            $a = Video::where('identify','=', $identify)->first();
            Cache::put('getVideoDetail'.$identify, $a, $minutes);
        }
        return $a;
    }

    public function getVideoHot()
    {
        $minutes = 15;
        if(Cache::has('getVideoHot'))
        {
            $a = Cache::get('getVideoHot');
        }
        else
        {
            $a = Video::where('listen_no_week','>',200)->orderBy('listen_no_week', 'DESC')->take(20)->get();
            Cache::put('getVideoHot', $a, $minutes);
        }
        return $a;
    }
    public function getVideoBySinger($singer_id)
    {
        $minutes = 15;
        if(Cache::has('getVideoBySinger'.$singer_id))
        {
            $a = Cache::get('getVideoBySinger'.$singer_id);
        }
        else
        {
            $a = DB::table('vt_video')->join('vt_video_singer', 'vt_video.id', '=', 'vt_video_singer.video_id')
                ->where('singer_id','=',$singer_id)->take(20)->get();
            Cache::put('getVideoBySinger'.$singer_id, $a, $minutes);
        }
        return $a;
    }
}