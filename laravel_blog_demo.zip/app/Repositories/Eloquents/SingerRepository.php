<?php

namespace App\Repositories\Eloquents;

use App\Repositories\Contracts\SingerRepositoryInterface;
use App\Singer;
use Illuminate\Support\Facades\DB;


class SingerRepository implements SingerRepositoryInterface
{
    public function all()
    {
        return Singer::all();
    }

    public function find($id)
    {
        return Singer::find($id);
    }
}