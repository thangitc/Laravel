<?php

namespace App\Repositories\Contracts;

use App\Video;

interface VideoRepositoryInterface
{
    public function all();
    public function find($id);
    public function getVideoDetail($identify);
    public function getVideoHot();
    public function getVideoBySinger($singer_id);
}