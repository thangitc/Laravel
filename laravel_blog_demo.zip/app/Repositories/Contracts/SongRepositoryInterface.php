<?php

namespace App\Repositories\Contracts;

use App\Song;

interface SongRepositoryInterface
{
    public function all();
    public function find($id);
    public function getSongDetail($identify);
    public function getSongRelated();
    public function getSongHot();
    public function getSingerBySong($song_id);
    public function getCatBySong($song_id);
    public function getAuthorBySong($song_id);
}