<?php

namespace App\Repositories\Contracts;

use App\Singer;

interface SingerRepositoryInterface
{
    public function all();
    public function find($id);
}