<?php

namespace App\Providers;

use App\Repositories\Contracts\SongRepositoryInterface;
use App\Repositories\Eloquents\SongRepository;
use App\Repositories\Contracts\VideoRepositoryInterface;
use App\Repositories\Eloquents\VideoRepository;
use App\Repositories\Contracts\SingerRepositoryInterface;
use App\Repositories\Eloquents\SingerRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(SongRepositoryInterface::class,SongRepository::class);
        $this->app->bind(SingerRepositoryInterface::class,SingerRepository::class);
        $this->app->bind(VideoRepositoryInterface::class,VideoRepository::class);
    }
}
