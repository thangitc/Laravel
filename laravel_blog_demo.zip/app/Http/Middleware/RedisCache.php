<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Cache;

class RedisCache
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        echo "RedisCache";
        $key = $request->url();
        if (Cache::has($key))
        {
            return response()->make(Cache::get($key));
        }

        return $next($request);
    }
    public function terminate($request, $response)
    {
        echo "After response";
        $key = $request->url();
        if (!Cache::has($key)) {
            Cache::put($key, $response->getContent(), 1);
        }
        //dump($response->getContent());
        return $response;
    }
}
