<?php

namespace App\Http\Controllers;
use App\Repositories\Contracts\SingerRepositoryInterface;
use App\Repositories\Contracts\SongRepositoryInterface;
use App\Repositories\Contracts\VideoRepositoryInterface;

use App\Song;
use App\Singer;
use App\Video;

use Illuminate\Http\Request;
use Redis;
use Cache;
class SongController extends Controller
{
    protected $repository;
    protected $singerRepository;
    protected $videoRepository;

    public function __construct(SongRepositoryInterface $repository,
                                SingerRepositoryInterface $singerRepository,
                                VideoRepositoryInterface $videoRepository
    )
    {
        $this->repository = $repository;
        $this->singerRepository = $singerRepository;
        $this->videoRepository = $videoRepository;
    }
    public function index()
    {
        $songs = $this->repository->all();
        return $songs;
    }

    public function show($id)
    {
        $detail = $this->repository->find($id);
        return $detail;
    }
    public function getSongDetail($identify)
    {
        //Chi tiet bai hat
        $detail = $this->repository->getSongDetail($identify);
        if(!empty($detail))
        {
            $song_id = $detail->id;
            //Thong tin ca si
            $singer_info = $this->repository->getSingerBySong($song_id);
            $singer_id = isset($singer_info->id) ? intval($singer_info->id) : 0;
            $detail->singer_name = isset($singer_info->real_name) ? $singer_info->real_name : '';
            $detail->info = isset($singer_info->info) ? $singer_info->info : '';

            //Thong tin chuyen muc
            $cat_info = $this->repository->getCatBySong($song_id);
            $detail->cat_name = isset($cat_info->name) ? $cat_info->name : '';

            //Thong tin Author
            $author_info = $this->repository->getAuthorBySong($song_id);
            $detail->author_name = isset($author_info->real_name) ? $author_info->real_name : '';

            //Bai hat noi bat
            $song_hot = $this->repository->getSongHot();

            //Video cung ca sy
            $videos = $this->videoRepository->getVideoBySinger($singer_id);

            $data = ['detail'=>$detail, 'singer_info'=>$singer_info, 'song_hot'=>$song_hot, 'videos'=>$videos];
            return view('song.detail',$data);
            //return response()->view('song.detail',$data);
        }
        else
        {
            return view("errors.404");
        }
    }
    public function cacheDB()
    {
        $minutes = 1;

        if(Cache::has('song'))
        {
            echo 'a';
            $a = Cache::get('song');
        }
        else
        {
            echo 'b';
            $a = Song::where('id','=',12)->first();
            //$a = response()->json($list);
            Cache::put('song', $a, $minutes);
        }

        return $a;

        $a = Cache::remember('song',$minutes,function(){
            return Song::where('id','=',12)->first();
        });

        return response()->json($a);
    }
    public function demoCache()
    {
        $value = json_encode([1,2,3]);
        //$redis = Redis::connection();
        Redis::set('foo', 'bar');
        /*
        $redis->set('foo', 'bar');
        $redis->set('foo1', $value);
        $redis->set('foo2', 2);
        //$name = $redis->get('foo');
        */
        //$name = $redis->get('foo');
        $name = Redis::get('foo');
        echo $name;
    }
}