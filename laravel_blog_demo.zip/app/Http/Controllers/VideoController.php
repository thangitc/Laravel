<?php

namespace App\Http\Controllers;

use App\Repositories\Contracts\SongRepositoryInterface;
use App\Repositories\Contracts\VideoRepositoryInterface;
use App\Repositories\Contracts\SingerRepositoryInterface;
use Illuminate\Http\Request;
use App\Video;
use DB;
class VideoController extends Controller
{
    protected $songRepository;
    protected $singerRepository;
    protected $videoRepository;
    public function __construct(VideoRepositoryInterface $videoRepository,
                                SongRepositoryInterface $songRepository,
                                SingerRepositoryInterface $singerRepository

    )
    {
        $this->videoRepository = $videoRepository;
        $this->songRepository = $songRepository;
        $this->singerRepository = $singerRepository;

    }
    public function getVideoDetail($identify)
    {
        $detail = Video::where('identify','=',$identify)->first();
        if(!empty($detail))
        {
            $row = Video::find($detail->id);
            $video_id = $row->id;
            //Thong tin ca si
            $singer_info = $row->singer->toArray();
            $singer_id = isset($singer_info[0]['id']) ? intval($singer_info[0]['id']) : 0;
            $detail->singer_name = isset($singer_info[0]['real_name']) ? $singer_info[0]['real_name'] : '';
            //Thong tin chuyen muc
            $cat_info = $row->cats->toArray();
            $detail->cat_name = isset($cat_info[0]['name']) ? $cat_info[0]['name'] : '';

            //Video de xuat
            $videos = DB::table('vt_video')->where('listen_no','>=',500)->orderBy('listen_no', 'DESC')->take(20)->get();
            $data = ['detail'=>$detail, 'videos'=>$videos];
            return view("video.detail", $data);
        }
        else
        {
            //return response()->view('errors.404');
            return view("errors.404");
        }
    }
}
