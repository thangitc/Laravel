<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Song extends Model
{
    public $table = 'vt_song';
    protected $fillable = [ 'name', 'lyric', 'slug', 'identify', 'singer_name', 'path',
                            'seo_title', 'seo_description', 'seo_keywords'
    ];
    public function singer()
    {
        return $this->belongsToMany(Singer::class, 'vt_song_singer', 'song_id', 'singer_id');
    }
    public function cats()
    {
        return $this->belongsToMany(Cats::class, 'vt_song_category', 'song_id', 'category_id');
    }
    public function author()
    {
        return $this->belongsToMany(Author::class, 'vt_song_author', 'song_id', 'author_id');
    }
    public function video()
    {
        return $this->belongsTo(Video::class);
    }
}
